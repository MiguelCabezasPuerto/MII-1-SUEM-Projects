/* ###################################################################
**     Filename    : main.c
**     Project     : ReactorReception
**     Processor   : MKE06Z128VLK4
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2021-05-30, 15:52, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "Pins1.h"
#include "Bits1.h"
#include "BitsIoLdd1.h"
#include "CAN1.h"
#include "WAIT1.h"
#include "MCUC1.h"
#include "PPG1.h"
#include "PpgLdd1.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
#include "PDD_Includes.h"
#include "Init_Config.h"

#define RGB_RED 6
#define RGB_GREEN 5
#define RGB_BLUE 3
#define TONO_LAB 415
/* User includes (#include below this line is not maintained by Processor Expert) */

/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
void tone(word frecuencia){
PPG1_Enable();
PPG1_SetFreqHz(frecuencia);
}
void notone(void){
	PPG1_Disable();
	PPG1_ClrValue();
}
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */
  LDD_TDeviceData *g_CANPtr = NULL;
  g_CANPtr = CAN1_Init(NULL);
  uint8_t Message[3];
  LDD_CAN_TFrame Frame;
  Frame.Data=Message;
  LDD_TError error;

  Bits1_PutVal(RGB_GREEN);

  int danger;
  danger=0;


  for(;;){
	  error=CAN1_ReadFrame(g_CANPtr,0U,&Frame);
	  if(error==ERR_OK){
		  if(Frame.MessageID == (0x123U)){
			  danger=1;
			  Bits1_PutVal(RGB_RED);
			  tone(TONO_LAB);
		  }else if(Frame.MessageID == (0x124U)){
			  danger=0;
			  Bits1_PutVal(RGB_GREEN);
			  notone();
		  }
	  }else{
		  if(danger==0){
			  Bits1_PutVal(RGB_GREEN);
		  	  notone();
		  }
		  else{
			  Bits1_PutVal(RGB_RED);
			  tone(TONO_LAB);
		  }
	  }
  }

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
