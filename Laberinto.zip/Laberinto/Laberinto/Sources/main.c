/* ###################################################################
 **     Filename    : main.c
 **     Project     : Laberinto
 **     Processor   : MKE06Z128VLK4
 **     Version     : Driver 01.01
 **     Compiler    : GNU C Compiler
 **     Date/Time   : 2021-05-07, 08:46, # CodeGen: 0
 **     Abstract    :
 **         Main module.
 **         This module contains user's application code.
 **     Settings    :
 **     Contents    :
 **         No public methods
 **
 ** ###################################################################*/
/*!
 ** @file main.c
 ** @version 01.01
 ** @brief
 **         Main module.
 **         This module contains user's application code.
 */
/*!
 **  @addtogroup main_module main module documentation
 **  @{
 */
/* MODULE main */

/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "Pins1.h"
#include "WAIT1.h"
#include "MCUC1.h"
#include "AD1.h"
#include "AdcLdd1.h"
#include "Bits_Color.h"
#include "BitsIoLdd1.h"
#include "Bits_Botones.h"
#include "BitsIoLdd2.h"
#include "WAIT2.h"
#include "PPG1.h"
#include "PpgLdd1.h"
#include "TI1.h"
#include "TimerIntLdd1.h"
#include "TU1.h"
#include "TI2.h"
#include "TimerIntLdd2.h"
#include "TU2.h"
#include "WDog1.h"
#include "WatchDogLdd1.h"
#include "Term1.h"
#include "Inhr2.h"
#include "ASerialLdd2.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
#include "PDD_Includes.h"
#include "Init_Config.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#define RGB_GREEN 5
#define RGB_RED 6
#define TONE_CHOQUE_PARED 261
#define TONE_CHOQUE_JUGADOR 493
#define TONE_UNO 1
#define TONE_FIN 392
#define TIEMPO_JUEGO 180
#define FILAS 25
#define COLUMNAS 25
volatile bool g_Complete = FALSE;
volatile bool g_Complete2 = FALSE;
volatile int tiempoJuego = TIEMPO_JUEGO;
volatile int movimientosJ1;
volatile int movimientosJ2;
volatile bool empiezaPintadoTiempo;
volatile bool pintarJugadores;
int JUGADOR_GANA;

int laberinto[FILAS][COLUMNAS];

/* User includes (#include below this line is not maintained by Processor Expert) */
void tone(word frecuencia) {
	PPG1_Enable();
	PPG1_SetFreqHz(frecuencia);
}
void notone() {
	PPG1_Disable();
	PPG1_ClrValue();
}
void playtone(word *ptrT, int tono) {
	int i = tono;
	if (ptrT[i] != TONE_UNO) {
		if (tono == 1) { //CHOQUE PARED
			tone(ptrT[i]);
			WAIT1_Waitms(100);
		} else if (tono == 2) { // CHOQUE CON OTRO JUGADOR
			tone(ptrT[tono]);
			WAIT1_Waitms(100);
		} else { // FIN DE JUEGO
			tone(ptrT[tono]);
			WAIT1_Waitms(1000);
		}
	} else {
		notone();
	}
}
int pintarLaberinto() {
	char cadena[2];
	int i, j;
	char movimiento;
	tiempoJuego = TIEMPO_JUEGO;
	Term1_CRLF();
	Term1_Cls();

	//Term1_SetColor(clBlack, clBlack);

	for (i = 0; i < FILAS; i++) {
		for (j = 0; j < COLUMNAS; j++) {
			//printf("%d\t",laberinto[i][j]);
			Term1_MoveTo(((j + 1) * 2) + 1, ((i + 1) * 2) + 1);
			if (laberinto[i][j] == 1) {
				sprintf(cadena, " ");
				Term1_SetColor(clRed, clRed);
				Term1_SendStr(cadena); /* writing a string */
			}
			if (laberinto[i][j] == 0) {
				sprintf(cadena, " ");
				Term1_SetColor(clBlack, clBlack);
				Term1_SendStr(cadena); /* writing a string */
			}
			if (laberinto[i][j] == 2) {
				sprintf(cadena, " ");
				Term1_SetColor(clGreen, clGreen);
				Term1_SendStr(cadena); /* writing a string */
			}
			if (laberinto[i][j] == 3) {
				sprintf(cadena, " ");
				Term1_SetColor(clBlue, clBlue);
				Term1_SendStr(cadena); /* writing a string */
			}
			if (laberinto[i][j] == 4) {
				sprintf(cadena, " ");
				Term1_SetColor(clWhite, clWhite);
				Term1_SendStr(cadena); /* writing a string */
			}
		}
	}

	Term1_SetColor(clWhite, clBlack); /*Color frente, color fondo*/
	Term1_MoveTo(1, 1);
	Term1_SendStr("T"); /* writing a string */
	Term1_MoveTo(2, 1);
	Term1_SendStr("I"); /* writing a string */
	Term1_MoveTo(3, 1);
	Term1_SendStr("E"); /* writing a string */
	Term1_MoveTo(4, 1);
	Term1_SendStr("M"); /* writing a string */
	Term1_MoveTo(5, 1);
	Term1_SendStr("P"); /* writing a string */
	Term1_MoveTo(6, 1);
	Term1_SendStr("O"); /* writing a string */
	Term1_MoveTo(7, 1);
	Term1_SendStr(":"); /* writing a string */

	Term1_MoveTo(22, 1);
	Term1_SendStr("A"); /* writing a string */
	Term1_MoveTo(23, 1);
	Term1_SendStr(":"); /* writing a string */

	Term1_MoveTo(30, 1);
	Term1_SendStr("B"); /* writing a string */
	Term1_MoveTo(31, 1);
	Term1_SendStr(":"); /* writing a string */

	Term1_MoveTo(1, 1);
	Term1_SetColor(clBlack, clBlack);
	//printf("\n\n");
	empiezaPintadoTiempo = TRUE;
}
int pulsacionBotonComienzoPartida() {

	empiezaPintadoTiempo = FALSE;
	int botonPulsado;
	byte leido;
	botonPulsado = 0;
	int posX, posY, posXAux, posYAux, posXSalida, posYSalida;
	int posX2, posY2;
	int i, j;
	TI1_Disable();
	TI2_Disable();

	for (i = 0; i < FILAS; i++) {
		for (j = 0; j < COLUMNAS; j++) {
			laberinto[i][j] = 0;
		}
	}

	for (i = 8; i < 15; i++) {
		Term1_SetColor(clBlack, clBlack);
		Term1_MoveTo(1, i);
		Term1_SendStr(" ");
	}
	pintarLaberinto();

	do {
		leido = Bits_Botones_GetVal();
		if (leido == 1) {
			Bits_Color_PutVal(RGB_GREEN);
			botonPulsado = 1;
		}
		WAIT1_Waitms(500);
	} while (botonPulsado == 0);

	posX = posY = 1;
	posX2 = 1;
	posY2 = COLUMNAS - 2;
	//Posicion Salida
	posXSalida = FILAS - 1;
	posYSalida = (COLUMNAS - 1) / 2;
	//Se rellena el laberinto
	// Fila superior
	for (i = 0; i < 1; i++) {
		for (j = 0; j < COLUMNAS; j++) {
			laberinto[i][j] = 1;
		}
	}
	// Fila inferior
	for (i = FILAS - 1; i < FILAS; i++) {
		for (j = 0; j < COLUMNAS; j++) {
			laberinto[i][j] = 1;
		}
	}
	//Primera columna
	for (i = 1; i < FILAS; i++) {
		for (j = 0; j < 1; j++) {
			laberinto[i][j] = 1;
		}
	}
	//Ultima columna
	for (i = 1; i < FILAS; i++) {
		for (j = COLUMNAS - 1; j < COLUMNAS; j++) {
			laberinto[i][j] = 1;
		}
	}
	// Se pone todo como paredes
	for (i = 1; i < FILAS - 1; i++) {
		for (j = 1; j < COLUMNAS - 1; j++) {
			laberinto[i][j] = 1;
		}
	}
	//Puntos de partida
	laberinto[posX][posY] = 3;
	laberinto[posX2][posY2] = 4;
	//Punto de salida
	laberinto[posXSalida][posYSalida] = 2;

	// Se marcan las casillas libres
	for (i = 2; i < 9; i++) {
		laberinto[i][1] = 0;
		laberinto[i][23] = 0;
	}
	laberinto[8][2] = 0;
	laberinto[11][2] = 0;
	laberinto[8][22] = 0;
	laberinto[11][22] = 0;
	for (i = 14; i < 23; i++) {
		laberinto[i][2] = 0;
		laberinto[i][22] = 0;
	}
	laberinto[8][3] = 0;
	laberinto[11][3] = 0;
	laberinto[12][3] = 0;
	laberinto[14][3] = 0;
	laberinto[22][3] = 0;

	laberinto[8][21] = 0;
	laberinto[11][21] = 0;
	laberinto[12][21] = 0;
	laberinto[14][21] = 0;
	laberinto[22][21] = 0;

	for (i = 2; i < 9; i++) {
		laberinto[i][4] = 0;
		laberinto[i][20] = 0;
	}

	laberinto[12][4] = 0;
	laberinto[14][4] = 0;
	laberinto[12][20] = 0;
	laberinto[14][20] = 0;
	for (i = 18; i < 23; i++) {
		laberinto[i][4] = 0;
		laberinto[i][20] = 0;
	}

	laberinto[2][5] = 0;
	laberinto[12][5] = 0;
	laberinto[14][5] = 0;
	laberinto[18][5] = 0;

	laberinto[2][19] = 0;
	laberinto[12][19] = 0;
	laberinto[14][19] = 0;
	laberinto[18][19] = 0;

	laberinto[2][6] = 0;
	laberinto[2][18] = 0;
	for (i = 6; i < 10; i++) {
		laberinto[i][6] = 0;
		laberinto[i][18] = 0;
	}
	for (i = 11; i < 15; i++) {
		laberinto[i][6] = 0;
		laberinto[i][18] = 0;
	}
	laberinto[18][6] = 0;
	laberinto[18][18] = 0;

	laberinto[2][7] = 0;
	laberinto[9][7] = 0;
	laberinto[11][7] = 0;
	laberinto[14][7] = 0;

	laberinto[2][17] = 0;
	laberinto[9][17] = 0;
	laberinto[11][17] = 0;
	laberinto[14][17] = 0;
	for (i = 18; i < 22; i++) {
		laberinto[i][7] = 0;
		laberinto[i][17] = 0;
	}

	for (i = 2; i < 6; i++) {
		laberinto[i][8] = 0;
		laberinto[i][16] = 0;
	}
	laberinto[9][8] = 0;
	laberinto[11][8] = 0;
	laberinto[14][8] = 0;
	laberinto[15][8] = 0;
	laberinto[21][8] = 0;
	laberinto[9][16] = 0;
	laberinto[11][16] = 0;
	laberinto[14][16] = 0;
	laberinto[15][16] = 0;
	laberinto[21][16] = 0;

	for (i = 5; i < 10; i++) {
		laberinto[i][9] = 0;
		laberinto[i][15] = 0;
	}
	laberinto[11][9] = 0;
	laberinto[15][9] = 0;
	laberinto[11][15] = 0;
	laberinto[15][15] = 0;
	for (i = 18; i < 22; i++) {
		laberinto[i][9] = 0;
		laberinto[i][15] = 0;
	}

	laberinto[5][10] = 0;
	laberinto[11][10] = 0;
	laberinto[15][10] = 0;
	laberinto[18][10] = 0;
	laberinto[21][10] = 0;

	laberinto[5][14] = 0;
	laberinto[11][14] = 0;
	laberinto[15][14] = 0;
	laberinto[18][14] = 0;
	laberinto[21][14] = 0;

	for (i = 5; i < 12; i++) {
		laberinto[i][11] = 0;
		laberinto[i][13] = 0;
	}
	for (i = 15; i < 19; i++) {
		laberinto[i][11] = 0;
		laberinto[i][13] = 0;
	}
	laberinto[21][11] = 0;
	laberinto[21][13] = 0;

	for (i = 21; i < 24; i++) {
		laberinto[i][12] = 0;
	}

	for (i = 8; i < 15; i++) {
		Term1_SetColor(clBlack, clBlack);
		Term1_MoveTo(1, i);
		Term1_SendStr(" ");
	}
	pintarLaberinto();
	//tiempoJuego=TIEMPO_JUEGO;
	TI1_Enable();
	TI2_Enable();
	WDog1_Clear();
	WDog1_Enable();
	partida();
	printf("GANA UN JUGADOR metodo BOTON COMIENZO");
}

/*JUGADOR 1*/
int partida() {
	word g_TonoT[] = { TONE_UNO, TONE_CHOQUE_PARED, TONE_CHOQUE_JUGADOR,
	TONE_FIN };
	int i, j;
	int k = 0;
	float v[2], v2[2];
	word Measure[2], Measure2[2], Measure3[2], Measure4[2];
	;
	int posX, posY, posXAux, posYAux, posXSalida, posYSalida;
	int posX2, posY2, posXAux2, posYAux2;
	char movimiento;
	char cadena1[1];
	char cadena2[2];
	posX = posY = 1;
	posX2 = 1;
	posY2 = COLUMNAS - 2;

	movimientosJ1 = movimientosJ2 = 0;

	for (;;) {

		/*JUGADOR 1*/
		posXAux = posX;
		posYAux = posY;

		AD1_Measure(FALSE);

		//AD1_MeasureChan(FALSE,0);
		// AD1_MeasureChan(FALSE,1);
		while (!g_Complete)
			WAIT1_Waitms(1);
		g_Complete = FALSE;
		AD1_GetValue16(Measure);
		//AD1_GetChanValue16(0,Measure);
		//AD1_GetChanValue16(1,Measure2);

		//DETECTAR ARRIBA Y ABAJO JUGADOR 2
		AD1_MeasureChan(FALSE, 2);
		while (!g_Complete)
			WAIT1_Waitms(1);
		g_Complete = FALSE;
		AD1_GetChanValue16(2, Measure2);
		//DETECTAR IZQUIERDA Y DERECHA JUGADOR 2
		AD1_MeasureChan(FALSE, 3);
		while (!g_Complete)
			WAIT1_Waitms(1);
		g_Complete = FALSE;
		AD1_GetChanValue16(3, Measure3);

		v[0] = ((Measure[0] >> 4) * 3.06 / 4096);//+ ((Measure2[0]>>4)*3.06/4096);
		v[1] = ((Measure[1] >> 4) * 3.06 / 4096);//+ ((Measure2[1]>>4)*3.06/4096);

		v2[0] = ((Measure2[0] >> 4) * 3.06 / 4096);	//+ ((Measure2[0]>>4)*3.06/4096);
		v2[1] = ((Measure3[0] >> 4) * 3.06 / 4096);	//+ ((Measure2[1]>>4)*3.06/4096);

		// printf("JUGADOR 1: %f\t%f\n",v[0],v[1]);
		// printf("JUGADOR 2: %f\t%f\n",v2[0],v2[1]);

		/*JUGADOR 2*/
		posXAux2 = posX2;
		posYAux2 = posY2;
		/*	  AD1_MeasureChan(FALSE,2);//PONER JOYSTICK JUGADOR 2
		 while(!g_Complete)WAIT1_Waitms(1);
		 g_Complete = FALSE;
		 AD1_GetChanValue16(2,Measure2);
		 //AD1_GetValue16(Measure2); //PONER JOYSTICK JUGADOR 2
		 v2[0]= (Measure2[0]>>4)*3.06/4096;
		 v2[1]= (Measure2[1]>>4)*3.06/4096;*/

		/*JUGADOR 1*/

		if (v[0] != 1.54f && v[1] != 1.47f) {
			// ARRIBA
			if (v[0] < 1.54f && v[1] >= 1.44f && v[1] <= 1.90f) {
				//printf("ARRIBA");
				WAIT1_Waitms(500);
				v[0] = 1.54f;
				v[1] = 1.47f;
				if (laberinto[posX - 1][posY] == 1) {
					//printf("CHOQUE!\n");
					notone();
					playtone(g_TonoT, 1);
					notone();
				} else if (laberinto[posX - 1][posY] == 2) {
					// ENCENDER UN LED DE UN COLOR U OTRO, EN FUNCION DEL JUGADOR QUE GANE,  EN PLACA
					printf("PREMIO!\n");
					laberinto[posX][posY] = 0;
					laberinto[posX2][posY2] = 0;
					Term1_MoveTo(((posY + 1) * 2) + 1, ((posX + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					TI2_Disable();
					Term1_MoveTo(((posY2 + 1) * 2) + 1, ((posX2 + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					notone();
					playtone(g_TonoT, 3);
					notone();
					Bits_Color_PutVal(RGB_RED);
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_CRLF();
					Term1_Cls();
					Term1_MoveTo(1, 1);
					Term1_SendStr("�Ha ganado el jugador A!"); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					WAIT1_Waitms(3000);
					pulsacionBotonComienzoPartida();
					break;
				} else if (laberinto[posX - 1][posY] == 4) {
					printf("CHOQUE OTRO JUGADOR!\n");
					notone();
					playtone(g_TonoT, 2);
					notone();
				} else {
					movimientosJ1 += 1;
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_MoveTo(24, 1);
					Term1_SendNum(movimientosJ1);
					posX--;
					laberinto[posXAux][posYAux] = 0;
					laberinto[posX][posY] = 3;
					//clrscr();
					//pintarLaberinto(laberinto);
					Term1_MoveTo(((posYAux + 1) * 2) + 1,
							((posXAux + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena1); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena1); /* writing a string */
					Term1_MoveTo(((posY + 1) * 2) + 1, ((posX + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlue, clBlue); /* red text on black background */
					Term1_SendStr(cadena1); /* writing a string */
					Term1_MoveTo(1, 1);
				}

			}
			//ABAJO
			else if (v[0] >= 2.5f && v[1] >= 1.44f && v[1] <= 1.90f) {
				//  printf("ABAJO");
				WAIT1_Waitms(500);
				v[0] = 1.54f;
				v[1] = 1.47f;
				if (laberinto[posX + 1][posY] == 1) {
					//	printf("CHOQUE!\n");
					notone();
					playtone(g_TonoT, 1);
					notone();

				} else if (laberinto[posX + 1][posY] == 2) {
					// ENCENDER UN LED DE UN COLOR U OTRO, EN FUNCION DEL JUGADOR QUE GANE,  EN PLACA
					printf("PREMIO!\n");
					laberinto[posX][posY] = 0;
					laberinto[posX2][posY2] = 0;
					Term1_MoveTo(((posY + 1) * 2) + 1, ((posX + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					TI2_Disable();
					Term1_MoveTo(((posY2 + 1) * 2) + 1, ((posX2 + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					notone();
					playtone(g_TonoT, 3);
					notone();
					Bits_Color_PutVal(RGB_RED);
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_CRLF();
					Term1_Cls();
					Term1_MoveTo(1, 1);
					Term1_SendStr("�Ha ganado el jugador A!"); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					WAIT1_Waitms(3000);
					pulsacionBotonComienzoPartida();
					break;
				} else if (laberinto[posX + 1][posY] == 4) {
					printf("CHOQUE OTRO JUGADOR!\n");
					notone();
					playtone(g_TonoT, 2);
					notone();
				} else {
					movimientosJ1 += 1;
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_MoveTo(24, 1);
					Term1_SendNum(movimientosJ1);
					posX++;
					laberinto[posXAux][posYAux] = 0;
					laberinto[posX][posY] = 3;
					//clrscr();
//				  				pintarLaberinto(laberinto);
					//pintarLaberinto(laberinto);
					Term1_MoveTo(((posYAux + 1) * 2) + 1,
							((posXAux + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena1); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena1); /* writing a string */
					Term1_MoveTo(((posY + 1) * 2) + 1, ((posX + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlue, clBlue); /* red text on black background */
					Term1_SendStr(cadena1); /* writing a string */
					Term1_MoveTo(1, 1);
				}
			}
			//IZQUIERDA
			else if (v[1] >= 2.5f && v[0] >= 1.44f && v[0] <= 1.58f) {
				// printf("IZQUIERDA");
				WAIT1_Waitms(500);
				v[0] = 1.54f;
				v[1] = 1.47f;
				if (laberinto[posX][posY - 1] == 1) {
					printf("CHOQUE!\n");
					notone();
					playtone(g_TonoT, 1);
					notone();
				} else if (laberinto[posX][posY - 1] == 2) {
					// ENCENDER UN LED DE UN COLOR U OTRO, EN FUNCION DEL JUGADOR QUE GANE,  EN PLACA
					printf("PREMIO!\n");
					laberinto[posX][posY] = 0;
					laberinto[posX2][posY2] = 0;
					Term1_MoveTo(((posY + 1) * 2) + 1, ((posX + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					TI2_Disable();
					Term1_MoveTo(((posY2 + 1) * 2) + 1, ((posX2 + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					notone();
					playtone(g_TonoT, 3);
					notone();
					Bits_Color_PutVal(RGB_RED);
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_CRLF();
					Term1_Cls();
					Term1_MoveTo(1, 1);
					Term1_SendStr("�Ha ganado el jugador A!"); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					WAIT1_Waitms(3000);
					pulsacionBotonComienzoPartida();
					break;
				} else if (laberinto[posX][posY - 1] == 4) {
					printf("CHOQUE OTRO JUGADOR!\n");
					notone();
					playtone(g_TonoT, 2);
					notone();
				} else {
					movimientosJ1 += 1;
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_MoveTo(24, 1);
					Term1_SendNum(movimientosJ1);
					posY--;
					laberinto[posXAux][posYAux] = 0;
					laberinto[posX][posY] = 3;
					//clrscr();
					//pintarLaberinto(laberinto);
					Term1_MoveTo(((posYAux + 1) * 2) + 1,
							((posXAux + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena1); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena1); /* writing a string */
					Term1_MoveTo(((posY + 1) * 2) + 1, ((posX + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlue, clBlue); /* red text on black background */
					Term1_SendStr(cadena1); /* writing a string */
					Term1_MoveTo(1, 1);
				}
			}
			//DERECHA
			else if (v[1] <= 0.8f && v[0] >= 1.44f && v[0] <= 1.58f) {
				//printf("DERECHA");
				WAIT1_Waitms(500);
				v[0] = 1.54f;
				v[1] = 1.47f;
				if (laberinto[posX][posY + 1] == 1) {
					printf("CHOQUE!\n");
					notone();
					playtone(g_TonoT, 1);
					notone();
				} else if (laberinto[posX][posY + 1] == 2) {
					printf("PREMIO!\n");
					laberinto[posX][posY] = 0;
					laberinto[posX2][posY2] = 0;
					Term1_MoveTo(((posY + 1) * 2) + 1, ((posX + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					TI2_Disable();
					Term1_MoveTo(((posY2 + 1) * 2) + 1, ((posX2 + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					notone();
					playtone(g_TonoT, 3);
					notone();
					Bits_Color_PutVal(RGB_RED);
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_CRLF();
					Term1_Cls();
					Term1_MoveTo(1, 1);
					Term1_SendStr("�Ha ganado el jugador A!"); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					WAIT1_Waitms(3000);
					pulsacionBotonComienzoPartida();
					break;
				} else if (laberinto[posX][posY + 1] == 4) {
					printf("CHOQUE OTRO JUGADOR!\n");
					notone();
					playtone(g_TonoT, 2);
					notone();
				} else {
					movimientosJ1++;
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_MoveTo(24, 1);
					Term1_SendNum(movimientosJ1);
					posY++;
					laberinto[posXAux][posYAux] = 0;
					laberinto[posX][posY] = 3;
					//clrscr();
					//pintarLaberinto(laberinto);
					Term1_MoveTo(((posYAux + 1) * 2) + 1,
							((posXAux + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena1); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena1); /* writing a string */
					Term1_MoveTo(((posY + 1) * 2) + 1, ((posX + 1) * 2) + 1);
					sprintf(cadena1, " ");
					Term1_SetColor(clBlue, clBlue); /* red text on black background */
					Term1_SendStr(cadena1); /* writing a string */
					Term1_MoveTo(1, 1);
				}
			}

		} else {
			printf("QUIETO");
			WAIT1_Waitms(500);
			v[0] = 1.54f;
			v[1] = 1.47f;
		}

		/*JUGADOR 2*/

		if (v2[0] != 1.51f && v2[1] != 1.61f) {
			// ARRIBA
			if (v2[0] <= 0.05f) {
				printf("ARRIBA");
				printf("%03d: %d %d | %0.2f %0.2f\r\n", k++, (Measure2[0] >> 4),
						(Measure3[0] >> 4), v2[0], v2[1]);
				WAIT1_Waitms(500);
				v2[0] = 1.51f;
				v2[1] = 1.61f;
				if (laberinto[posX2 - 1][posY2] == 1) {
					printf("CHOQUE J2 pared!\n");
					notone();
					playtone(g_TonoT, 1);
					notone();
				} else if (laberinto[posX2 - 1][posY2] == 2) {
					// ENCENDER UN LED DE UN COLOR U OTRO, EN FUNCION DEL JUGADOR QUE GANE,  EN PLACA
					printf("PREMIO!\n");
					laberinto[posX2][posY2] = 0;
					laberinto[posX][posY] = 0;
					Term1_MoveTo(((posY2 + 1) * 2) + 1, ((posX2 + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					TI2_Disable();
					Term1_MoveTo(((posY + 1) * 2) + 1, ((posX + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					notone();
					playtone(g_TonoT, 3);
					notone();
					Bits_Color_PutVal(RGB_RED);
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_CRLF();
					Term1_Cls();
					Term1_MoveTo(1, 1);
					Term1_SendStr("�Ha ganado el jugador B!"); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					WAIT1_Waitms(3000);
					pulsacionBotonComienzoPartida();
					break;
				} else if (laberinto[posX2 - 1][posY2] == 3) {
					printf("CHOQUE OTRO JUGADOR!\n");
					notone();
					playtone(g_TonoT, 2);
					notone();
				} else {
					movimientosJ2++;
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_MoveTo(32, 1);
					Term1_SendNum(movimientosJ2);
					posX2--;
					laberinto[posXAux2][posYAux2] = 0;
					laberinto[posX2][posY2] = 4;
					//clrscr();
//		 				  				pintarLaberinto(laberinto);
					Term1_MoveTo(((posYAux2 + 1) * 2) + 1,
							((posXAux2 + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena2); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena2); /* writing a string */
					Term1_MoveTo(((posY2 + 1) * 2) + 1, ((posX2 + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clWhite, clWhite); /* red text on black background */
					Term1_SendStr(cadena2); /* writing a string */
					Term1_MoveTo(0, 0);
				}

			}
			//ABAJO
			else if (v2[0] >= 3.0f) {
				printf("ABAJO");
				printf("%03d: %d %d | %0.2f %0.2f\r\n", k++, (Measure2[0] >> 4),
						(Measure3[0] >> 4), v2[0], v2[1]);
				WAIT1_Waitms(500);
				v2[0] = 1.51f;
				v2[1] = 1.61f;
				if (laberinto[posX2 + 1][posY2] == 1) {
					//	printf("CHOQUE!\n");
					notone();
					playtone(g_TonoT, 1);
					notone();

				} else if (laberinto[posX2 + 1][posY2] == 2) {
					// ENCENDER UN LED DE UN COLOR U OTRO, EN FUNCION DEL JUGADOR QUE GANE,  EN PLACA
					printf("PREMIO!\n");
					laberinto[posX2][posY2] = 0;
					laberinto[posX][posY] = 0;
					Term1_MoveTo(((posY2 + 1) * 2) + 1, ((posX2 + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					TI2_Disable();
					Term1_MoveTo(((posY + 1) * 2) + 1, ((posX + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					notone();
					playtone(g_TonoT, 3);
					notone();
					Bits_Color_PutVal(RGB_RED);
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_CRLF();
					Term1_Cls();
					Term1_MoveTo(1, 1);
					Term1_SendStr("�Ha ganado el jugador B!"); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					WAIT1_Waitms(3000);
					pulsacionBotonComienzoPartida();
					break;
				} else if (laberinto[posX2 + 1][posY2] == 3) {
					printf("CHOQUE OTRO JUGADOR!\n");
					notone();
					playtone(g_TonoT, 2);
					notone();
				} else {
					movimientosJ2++;
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_MoveTo(32, 1);
					Term1_SendNum(movimientosJ2);
					posX2++;
					laberinto[posXAux2][posYAux2] = 0;
					laberinto[posX2][posY2] = 4;
					//clrscr();
					//pintarLaberinto(laberinto);
					Term1_MoveTo(((posYAux2 + 1) * 2) + 1,
							((posXAux2 + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena2); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena2); /* writing a string */
					Term1_MoveTo(((posY2 + 1) * 2) + 1, ((posX2 + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clWhite, clWhite); /* red text on black background */
					Term1_SendStr(cadena2); /* writing a string */
					Term1_MoveTo(0, 0);
				}
			}
			//IZQUIERDA
			else if (v2[1] >= 3.0f) {
				printf("IZQUIERDA");
				printf("%03d: %d %d | %0.2f %0.2f\r\n", k++, (Measure2[0] >> 4),
						(Measure3[0] >> 4), v2[0], v2[1]);
				WAIT1_Waitms(500);
				v2[0] = 1.51f;
				v2[1] = 1.61f;
				if (laberinto[posX2][posY2 - 1] == 1) {
					printf("CHOQUE!\n");
					notone();
					playtone(g_TonoT, 1);
					notone();
				} else if (laberinto[posX2][posY2 - 1] == 2) {
					// ENCENDER UN LED DE UN COLOR U OTRO, EN FUNCION DEL JUGADOR QUE GANE,  EN PLACA
					printf("PREMIO!\n");
					laberinto[posX2][posY2] = 0;
					laberinto[posX][posY] = 0;
					Term1_MoveTo(((posY2 + 1) * 2) + 1, ((posX2 + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					TI2_Disable();
					Term1_MoveTo(((posY + 1) * 2) + 1, ((posX + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					notone();
					playtone(g_TonoT, 3);
					notone();
					Bits_Color_PutVal(RGB_RED);
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_CRLF();
					Term1_Cls();
					Term1_MoveTo(1, 1);
					Term1_SendStr("�Ha ganado el jugador B!"); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					WAIT1_Waitms(3000);
					pulsacionBotonComienzoPartida();
					break;
				} else if (laberinto[posX2][posY2 - 1] == 3) {
					printf("CHOQUE OTRO JUGADOR!\n");
					notone();
					playtone(g_TonoT, 2);
					notone();
				} else {
					movimientosJ2++;
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_MoveTo(32, 1);
					Term1_SendNum(movimientosJ2);
					posY2--;
					laberinto[posXAux2][posYAux2] = 0;
					laberinto[posX2][posY2] = 4;
					//clrscr();
					//pintarLaberinto(laberinto);
					Term1_MoveTo(((posYAux2 + 1) * 2) + 1,
							((posXAux2 + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena2); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena2); /* writing a string */
					Term1_MoveTo(((posY2 + 1) * 2) + 1, ((posX2 + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clWhite, clWhite); /* red text on black background */
					Term1_SendStr(cadena2); /* writing a string */
					Term1_MoveTo(0, 0);
				}
			}
			//DERECHA
			else if (v2[1] <= 0.15) {
				printf("DERECHA");
				printf("%03d: %d %d | %0.2f %0.2f\r\n", k++, (Measure2[0] >> 4),
						(Measure3[0] >> 4), v2[0], v2[1]);
				WAIT1_Waitms(500);
				v2[0] = 1.51f;
				v2[1] = 1.61f;
				if (laberinto[posX2][posY2 + 1] == 1) {
					printf("CHOQUE!\n");
					notone();
					playtone(g_TonoT, 1);
					notone();
				} else if (laberinto[posX2][posY2 + 1] == 2) {
					printf("PREMIO!\n");
					laberinto[posX2][posY2] = 0;
					laberinto[posX][posY] = 0;
					Term1_MoveTo(((posY2 + 1) * 2) + 1, ((posX2 + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					TI2_Disable();
					Term1_MoveTo(((posY + 1) * 2) + 1, ((posX + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					notone();
					playtone(g_TonoT, 3);
					notone();
					Bits_Color_PutVal(RGB_RED);
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_CRLF();
					Term1_Cls();
					Term1_MoveTo(1, 1);
					Term1_SendStr("�Ha ganado el jugador B!"); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					WAIT1_Waitms(3000);
					pulsacionBotonComienzoPartida();
					break;
				} else if (laberinto[posX2][posY2 + 1] == 3) {
					printf("CHOQUE OTRO JUGADOR!\n");
					notone();
					playtone(g_TonoT, 2);
					notone();
				} else {
					movimientosJ2++;
					Term1_SetColor(clWhite, clBlack); /* red text on black background */
					Term1_MoveTo(32, 1);
					Term1_SendNum(movimientosJ2);
					posY2++;
					laberinto[posXAux2][posYAux2] = 0;
					laberinto[posX2][posY2] = 4;
					//clrscr();
					//pintarLaberinto(laberinto);
					Term1_MoveTo(((posYAux2 + 1) * 2) + 1,
							((posXAux2 + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena2); /* writing a string */
					Term1_SetColor(clBlack, clBlack); /* red text on black background */
					Term1_SendStr(cadena2); /* writing a string */
					Term1_MoveTo(((posY2 + 1) * 2) + 1, ((posX2 + 1) * 2) + 1);
					sprintf(cadena2, " ");
					Term1_SetColor(clWhite, clWhite); /* red text on black background */
					Term1_SendStr(cadena2); /* writing a string */
					Term1_MoveTo(0, 0);
				}
			}

		} else {
			printf("QUIETO");
			printf("%03d: %d %d | %0.2f %0.2f\r\n", k++, (Measure2[0] >> 4),
					(Measure3[0] >> 4), v2[0], v2[1]);
			WAIT1_Waitms(500);
			v2[0] = 1.51f;
			v2[1] = 1.61f;
		}

	} // fin bucle FOR

	printf("GANA UN JUGADOR metodo partida");
}
/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
	/* Write your local variable definition here */

	/*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
	PE_low_level_init();
	/*** End of Processor Expert internal initialization.                    ***/

	/* Write your code here */
	notone();
	/* For example: for(;;) { } */
	//Posicion inicial
	pulsacionBotonComienzoPartida();

	/*** Don't write any code pass this line, or it will be deleted during code generation. ***/
	/*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
#ifdef PEX_RTOS_START
	PEX_RTOS_START(); /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
#endif
	/*** End of RTOS startup code.  ***/
	/*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
	for (;;) {
	}
	/*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
 ** @}
 */
/*
 ** ###################################################################
 **
 **     This file was created by Processor Expert 10.5 [05.21]
 **     for the Freescale Kinetis series of microcontrollers.
 **
 ** ###################################################################
 */
