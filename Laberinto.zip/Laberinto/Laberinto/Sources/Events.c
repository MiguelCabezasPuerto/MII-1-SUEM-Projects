/* ###################################################################
**     Filename    : Events.c
**     Project     : Laberinto
**     Processor   : MKE06Z128VLK4
**     Component   : Events
**     Version     : Driver 01.00
**     Compiler    : GNU C Compiler
**     Date/Time   : 2021-05-07, 08:46, # CodeGen: 0
**     Abstract    :
**         This is user's event module.
**         Put your event handler code here.
**     Contents    :
**         Cpu_OnNMI - void Cpu_OnNMI(void);
**
** ###################################################################*/
/*!
** @file Events.c
** @version 01.00
** @brief
**         This is user's event module.
**         Put your event handler code here.
*/         
/*!
**  @addtogroup Events_module Events module documentation
**  @{
*/         
/* MODULE Events */

#include "Cpu.h"
#include "Events.h"
#include "Init_Config.h"
#include "PDD_Includes.h"
#define RGB_RED 6

#ifdef __cplusplus
extern "C" {
#endif 


/* User includes (#include below this line is not maintained by Processor Expert) */

/*
** ===================================================================
**     Event       :  Cpu_OnNMI (module Events)
**
**     Component   :  Cpu [MKE06Z128LK4]
*/
/*!
**     @brief
**         This event is called when the Non maskable interrupt had
**         occurred. This event is automatically enabled when the [NMI
**         interrupt] property is set to 'Enabled'.
*/
/* ===================================================================*/
void Cpu_OnNMI(void)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  AD1_OnEnd (module Events)
**
**     Component   :  AD1 [ADC]
**     Description :
**         This event is called after the measurement (which consists
**         of <1 or more conversions>) is/are finished.
**         The event is available only when the <Interrupt
**         service/event> property is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
extern volatile bool g_Complete;
extern volatile bool g_Complete2;

void AD1_OnEnd(void)
{
  /* Write your code here ... */
	g_Complete = TRUE;
	//g_Complete2 = TRUE;
}

/*
** ===================================================================
**     Event       :  TI1_OnInterrupt (module Events)
**
**     Component   :  TI1 [TimerInt]
**     Description :
**         When a timer interrupt occurs this event is called (only
**         when the component is enabled - <Enable> and the events are
**         enabled - <EnableEvent>). This event is enabled only if a
**         <interrupt service/event> is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
extern volatile int tiempoJuego;
extern volatile int movimientosJ1,movimientosJ2;
void TI1_OnInterrupt(void)
{
	TI2_Disable();
  //printf("\nTIEMPO AGOTADO!!!\n");
  int j1,j2;
  j1=movimientosJ1;
  j2=movimientosJ2;
  Bits_Color_PutVal(RGB_RED);
  if(j1>j2){
	  Term1_SetColor(clWhite, clBlack); /* red text on black background */
	  Term1_CRLF();
	  Term1_Cls();
	  Term1_MoveTo(1,1);
	  Term1_SendStr("�Ha ganado el jugador A!"); /* writing a string */
  }else if(j1<j2){
	  Term1_SetColor(clWhite, clBlack); /* red text on black background */
	  Term1_CRLF();
	  Term1_Cls();
	  Term1_MoveTo(1,1);
	  Term1_SendStr("�Ha ganado el jugador B!"); /* writing a string */
  }else{
	  Term1_SetColor(clWhite, clBlack); /* red text on black background */
	  Term1_CRLF();
	  Term1_Cls();
	  Term1_MoveTo(1,1);
	  Term1_SendStr("�Empate!"); /* writing a string */
  }
  Term1_SetColor(clBlack, clBlack);
  Term1_MoveTo(1,2);
  Term1_SendStr("    ");
  Term1_SetColor(clBlack, clBlack);
   Term1_MoveTo(1,3);
   Term1_SendStr("    ");
  Term1_SetColor(clBlack, clBlack);
  tiempoJuego=30;
  //return 0;
 // pulsacionBotonComienzoPartida();
}

/*
** ===================================================================
**     Event       :  TI2_OnInterrupt (module Events)
**
**     Component   :  TI2 [TimerInt]
**     Description :
**         When a timer interrupt occurs this event is called (only
**         when the component is enabled - <Enable> and the events are
**         enabled - <EnableEvent>). This event is enabled only if a
**         <interrupt service/event> is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
extern volatile bool empiezaPintadoTiempo;
extern volatile bool pintarJugadores;
void TI2_OnInterrupt(void)
{
  int i;
  tiempoJuego--;

	for(i=8;i<15;i++){
		Term1_SetColor(clBlack, clBlack);
		Term1_MoveTo(1,i);
		Term1_SendStr(" ");
	}
  if(empiezaPintadoTiempo){
	  pintarJugadores=FALSE;
	  Term1_SetColor(clWhite, clBlack);
	    Term1_MoveTo(8,1);
	    Term1_SendNum(tiempoJuego);
		 Term1_SetColor(clWhite, clBlack);
		 Term1_MoveTo(8,1);
		 Term1_SendNum(tiempoJuego);
  }
  pintarJugadores=TRUE;
}

/* END Events */

#ifdef __cplusplus
}  /* extern "C" */
#endif 

/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
